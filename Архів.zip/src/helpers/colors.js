export const mainColor = "#29CC8F";
export const textColor = "#323232";
export const dangerColor = "#F68C8D";
export const greyColor = "#CCCCCC";
